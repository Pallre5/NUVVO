
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { createRoot } from 'react-dom/client';
import { GoogleGenAI } from "@google/genai";

const NAV_LINKS = ["Aura", "Archivo", "Nosotros"];
const ADMIN_EMAIL = "pallaresthomas22@gmail.com";

interface CartItem {
  id: string;
  name: string;
  size: string;
  price: number;
  image: string;
  quantity: number;
}

interface User {
  name: string;
  email: string;
  nodeId: string;
}

interface StockLevels {
  S: number;
  M: number;
  L: number;
}

interface Subscriber {
  id: string;
  email: string;
  joinDate: string;
  tier: 'General' | 'VIP' | 'Blacklist';
}

interface Coupon {
  code: string;
  discount: number;
}

const App = () => {
  const [brandName, setBrandName] = useState("nuvvo");
  const [heroText, setHeroText] = useState("Aura 001");
  const [announcement, setAnnouncement] = useState("ENVÍOS GRATIS A TODA COLOMBIA - DROP LIMITADO 001");
  const [accentColor, setAccentColor] = useState("#ff3b30");
  const [editMode, setEditMode] = useState(false);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [checkoutStep, setCheckoutStep] = useState<number>(1);
  const [isLocked, setIsLocked] = useState(false);
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [showRegistration, setShowRegistration] = useState(false);
  
  const [stock, setStock] = useState<StockLevels>({ S: 12, M: 15, L: 3 });
  const [subscribers, setSubscribers] = useState<Subscriber[]>([
    { id: '1', email: 'thomas@nuvvo.io', joinDate: '2023-10-01', tier: 'VIP' },
    { id: '2', email: 'admin@nuvvo.io', joinDate: '2023-09-15', tier: 'General' }
  ]);
  
  const [releaseDate, setReleaseDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 3);
    return d.toISOString();
  });

  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState(false);
  const [isSupportOpen, setIsSupportOpen] = useState(false);

  useEffect(() => {
    const lockStatus = localStorage.getItem('nuvvo_sys_status');
    const adminStatus = localStorage.getItem('nuvvo_admin_auth');
    const savedDate = localStorage.getItem('nuvvo_release_date');
    const savedUser = localStorage.getItem('nuvvo_current_user');

    if (lockStatus === 'offline') setIsLocked(true);
    if (adminStatus === ADMIN_EMAIL) setIsAdminLoggedIn(true);
    if (savedDate) setReleaseDate(savedDate);
    
    if (savedUser) {
      setCurrentUser(JSON.parse(savedUser));
    } else {
      setShowRegistration(true);
    }
  }, []);

  const handleRegister = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem('nuvvo_current_user', JSON.stringify(user));
    setSubscribers(prev => [...prev, { id: user.nodeId, email: user.email, joinDate: new Date().toISOString(), tier: 'General' }]);
  };

  const triggerLockdown = () => {
    setIsLocked(true);
    localStorage.setItem('nuvvo_sys_status', 'offline');
  };

  const handleAdminAuth = (email: string) => {
    if (email.toLowerCase().trim() === ADMIN_EMAIL) {
      setIsAdminLoggedIn(true);
      localStorage.setItem('nuvvo_admin_auth', ADMIN_EMAIL);
      setShowLogin(false);
      setIsLocked(false);
      localStorage.removeItem('nuvvo_sys_status');
      return true;
    }
    return false;
  };

  const handleUpdateReleaseDate = (date: string) => {
    setReleaseDate(date);
    localStorage.setItem('nuvvo_release_date', date);
  };

  const addToCart = (item: Omit<CartItem, 'quantity'>) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === item.id && i.size === item.size);
      if (existing) {
        return prev.map(i => i.id === item.id && i.size === item.size 
          ? { ...i, quantity: i.quantity + 1 } 
          : i
        );
      }
      return [...prev, { ...item, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const updateQuantity = (id: string, size: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id && item.size === size) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const removeFromCart = (id: string, size: string) => {
    setCart(prev => prev.filter(i => !(i.id === id && i.size === size)));
  };

  const cartTotal = useMemo(() => cart.reduce((acc, item) => acc + (item.price * item.quantity), 0), [cart]);

  const isDropLocked = new Date(releaseDate).getTime() > new Date().getTime();

  if (isLocked && !isAdminLoggedIn) {
    return (
      <>
        <LockdownScreen email={ADMIN_EMAIL} accent={accentColor} />
        <button 
          onClick={() => setShowLogin(true)}
          className="fixed bottom-8 left-8 text-[10px] font-black uppercase tracking-[0.3em] text-white/40 hover:text-white z-[210] border border-white/20 px-6 py-3 rounded-full backdrop-blur-md transition-all hover:bg-white/10"
        >
          Acceso Maestro
        </button>
        {showLogin && <AdminLoginModal accent={accentColor} onAuth={handleAdminAuth} onClose={() => setShowLogin(false)} />}
      </>
    );
  }

  return (
    <div className="min-h-screen flex flex-col transition-colors duration-500 text-white selection:bg-white selection:text-black bg-[#0a0a0a]">
      {showRegistration && <RegistrationModal onRegister={handleRegister} onClose={() => setShowRegistration(false)} accent={accentColor} dropTime={new Date(releaseDate).toLocaleString()} />}
      
      <div 
        style={{ backgroundColor: accentColor }}
        className="text-black py-2 overflow-hidden whitespace-nowrap border-b border-black fixed top-0 w-full z-[100]"
      >
        <div className="inline-block animate-marquee font-black uppercase tracking-[0.3em] text-[10px] italic">
          {announcement} • {announcement} • {announcement} • {announcement}
        </div>
      </div>

      <Navbar 
        brandName={brandName} 
        setBrandName={setBrandName} 
        editMode={editMode} 
        cartCount={cart.reduce((a, b) => a + b.quantity, 0)} 
        onOpenCart={() => setIsCartOpen(true)} 
        isAdmin={isAdminLoggedIn}
        accent={accentColor}
        currentUser={currentUser}
      />
      
      <div className="fixed top-40 right-6 z-50 flex flex-col gap-2">
        {isAdminLoggedIn ? (
          <button 
            onClick={() => setIsAdminLoggedIn(false)}
            className="px-6 py-3 rounded-full text-[10px] tracking-widest uppercase font-black bg-white text-black shadow-lg hover:opacity-80 transition-all"
          >
            Ir a la Tienda 
          </button>
        ) : (
          <button 
            onClick={() => setEditMode(!editMode)}
            className={`px-4 py-2 rounded-full text-[10px] tracking-widest uppercase font-black transition-all shadow-lg ${editMode ? 'bg-white text-black' : 'bg-black/50 text-white border border-white/20 backdrop-blur-md hover:bg-black/80'}`}
          >
            {editMode ? '✓ Guardar' : '✎ Edición Visual'}
          </button>
        )}
      </div>

      <main className="flex-grow pt-10">
        {isAdminLoggedIn ? (
          <AdminDashboard 
            brandName={brandName} 
            announcement={announcement} 
            setAnnouncement={setAnnouncement} 
            accent={accentColor}
            setAccent={setAccentColor}
            stock={stock}
            setStock={setStock}
            subscribers={subscribers}
            setSubscribers={setSubscribers}
            releaseDate={releaseDate}
            onUpdateReleaseDate={handleUpdateReleaseDate}
            isLocked={isLocked}
            setIsLocked={setIsLocked}
          />
        ) : (
          <>
            <HeroSection 
              heroText={heroText} 
              setHeroText={setHeroText} 
              editMode={editMode} 
              brandName={brandName} 
              accent={accentColor} 
              releaseDate={releaseDate}
            />
            <ProductShowcase 
              brandName={brandName} 
              onAddToCart={addToCart} 
              onOpenSizeGuide={() => setIsSizeGuideOpen(true)}
              accent={accentColor}
              stock={stock}
              isLocked={isDropLocked}
            />
            <ArchiveSection accent={accentColor} />
            <InfoSection brandName={brandName} accent={accentColor} />
          </>
        )}
      </main>
      
      {!isAdminLoggedIn && (
        <Footer 
          brandName={brandName} 
          onLock={triggerLockdown} 
          onAdminClick={() => setShowLogin(true)}
          onOpenSizeGuide={() => setIsSizeGuideOpen(true)}
          onOpenSupport={() => setIsSupportOpen(true)}
          isAdmin={isAdminLoggedIn}
          accent={accentColor}
          onSubscribe={(email) => setSubscribers(prev => [...prev, { id: Date.now().toString(), email, joinDate: new Date().toISOString(), tier: 'General' }])}
        />
      )}

      <CartDrawer 
        isOpen={isCartOpen} 
        onClose={() => setIsCartOpen(false)} 
        cart={cart} 
        onUpdateQuantity={updateQuantity}
        onRemove={removeFromCart} 
        total={cartTotal}
        onCheckout={() => { setIsCartOpen(false); setIsCheckoutOpen(true); }}
        accent={accentColor}
      />

      {isCheckoutOpen && (
        <CheckoutModal 
          step={checkoutStep} 
          setStep={setCheckoutStep} 
          onClose={() => { setIsCheckoutOpen(false); setCheckoutStep(1); }}
          total={cartTotal}
          cart={cart}
          user={currentUser}
          onFinalize={(receipt: any) => { 
            setStock(prev => ({ 
              ...prev, 
              S: prev.S - cart.filter(c => c.size === 'S').reduce((a,b) => a + b.quantity, 0),
              M: prev.M - cart.filter(c => c.size === 'M').reduce((a,b) => a + b.quantity, 0),
              L: prev.L - cart.filter(c => c.size === 'L').reduce((a,b) => a + b.quantity, 0)
            }));
            setCart([]);
          }}
          onLock={triggerLockdown}
          accent={accentColor}
        />
      )}

      {showLogin && <AdminLoginModal accent={accentColor} onAuth={handleAdminAuth} onClose={() => setShowLogin(false)} />}
      {isSizeGuideOpen && <SizeGuideModal accent={accentColor} onClose={() => setIsSizeGuideOpen(false)} />}
      {isSupportOpen && <SupportModal accent={accentColor} onClose={() => setIsSupportOpen(false)} />}
    </div>
  );
};

/* --- Registration Modal with 'Email' Notification --- */

const RegistrationModal = ({ onRegister, onClose, accent, dropTime }: { onRegister: (u: User) => void, onClose: () => void, accent: string, dropTime: string }) => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [step, setStep] = useState(1);
  const [isSending, setIsSending] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !email.includes("@")) return;
    
    setIsSending(true);
    setTimeout(() => {
      onRegister({ name, email, nodeId: `NX-${Math.floor(Math.random() * 99999).toString(16).toUpperCase()}` });
      setIsSending(false);
      setStep(2);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-[2000] bg-black/95 backdrop-blur-3xl flex items-center justify-center p-6 animate-in fade-in duration-700">
      <div className="w-full max-w-xl bg-[#0a0a0a] border border-white/10 rounded-[4rem] p-16 space-y-12 relative shadow-2xl overflow-hidden">
        {step === 1 ? (
          <>
            <div className="space-y-4">
              <span className="text-[10px] font-black tracking-[0.8em] italic uppercase" style={{ color: accent }}>Sistema de Registro</span>
              <h3 className="text-6xl font-black italic uppercase tracking-tighter">Bienvenido</h3>
              <p className="text-white/30 text-xs font-bold uppercase tracking-widest leading-relaxed">Sincroniza tu identidad para recibir los protocolos de acceso al Drop 001.</p>
            </div>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <label className="text-[9px] font-black uppercase opacity-20 ml-4">Nombre Completo</label>
                <input required value={name} onChange={e => setName(e.target.value)} className="w-full bg-white/5 border border-white/5 rounded-3xl py-6 px-10 text-sm font-bold text-white outline-none focus:border-white/20 transition-all italic" placeholder="NODO_NAME" />
              </div>
              <div className="space-y-2">
                <label className="text-[9px] font-black uppercase opacity-20 ml-4">Email de Protocolo</label>
                <input required type="email" value={email} onChange={e => setEmail(e.target.value)} className="w-full bg-white/5 border border-white/5 rounded-3xl py-6 px-10 text-sm font-bold text-white outline-none focus:border-white/20 transition-all italic" placeholder="EMAIL@NUVVO.IO" />
              </div>
              <button disabled={isSending} type="submit" style={{ backgroundColor: accent }} className="w-full py-10 rounded-full font-black uppercase tracking-[0.6em] text-sm hover:scale-[1.01] transition-all shadow-2xl active:scale-95 italic text-white flex items-center justify-center gap-4">
                {isSending ? <><div className="w-4 h-4 border-2 border-t-transparent border-white rounded-full animate-spin"></div> ENVIANDO...</> : 'VINCULAR CUENTA'}
              </button>
            </form>
          </>
        ) : (
          <div className="space-y-10 py-10 animate-in zoom-in duration-500 text-center">
            <div className="text-8xl" style={{ color: accent }}>📩</div>
            <div className="space-y-4">
              <h4 className="text-4xl font-black uppercase italic tracking-tighter">Protocolo Enviado</h4>
              <p className="text-white/40 text-xs font-bold uppercase tracking-[0.2em] leading-loose">
                Hemos enviado un correo a <span className="text-white underline">{email}</span> con los detalles. <br/>
                El Drop 001 inicia oficialmente el: <br/>
                <span className="text-lg text-white" style={{ color: accent }}>{dropTime}</span>
              </p>
            </div>
            <button onClick={onClose} className="w-full py-6 rounded-full border border-white/10 font-black uppercase text-[10px] tracking-widest hover:bg-white/5 transition-all">ACCEDER AL STUDIO</button>
          </div>
        )}
      </div>
    </div>
  );
};

/* --- Advanced OS 4.5 Admin Dashboard --- */

const AdminDashboard = ({ brandName, announcement, setAnnouncement, accent, setAccent, stock, setStock, subscribers, setSubscribers, releaseDate, onUpdateReleaseDate, isLocked, setIsLocked }: any) => {
  const [activeTab, setActiveTab] = useState<'analytics' | 'crm' | 'marketing' | 'inventory' | 'system' | 'tools'>('analytics');
  const [logs, setLogs] = useState<string[]>([`[${new Date().toLocaleTimeString()}] Kernel v4.5.1 Online.`]);

  useEffect(() => {
    const interval = setInterval(() => {
      const msgs = ["Sincronización de Inventario 100%", "Nodo Bogotá: Operacional", "Salud del Kernel: Óptima", "Nuevos registros en cola: 2", "Protocolo de Envío: Listo"];
      setLogs(prev => [`[${new Date().toLocaleTimeString()}] ${msgs[Math.floor(Math.random() * msgs.length)]}`, ...prev].slice(0, 15));
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const addLog = (msg: string) => {
    setLogs(prev => [`[${new Date().toLocaleTimeString()}] ${msg}`, ...prev].slice(0, 15));
  };

  return (
    <div className="pt-32 pb-40 px-6 max-w-7xl mx-auto animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row gap-12">
        <aside className="md:w-72 flex flex-col gap-3">
          {[
            { id: 'analytics', label: 'ANALYTICS', icon: '📊' },
            { id: 'crm', label: 'DATABASE', icon: '👥' },
            { id: 'marketing', label: 'AI CORE', icon: '✴️' },
            { id: 'inventory', label: 'STOCK', icon: '📦' },
            { id: 'system', label: 'OS PREFS', icon: '⚙️' },
            { id: 'tools', label: 'MASTER TOOLS', icon: '🛠️' },
          ].map(item => (
            <button key={item.id} onClick={() => setActiveTab(item.id as any)} className={`p-6 rounded-[2.5rem] text-left font-black uppercase tracking-widest text-[10px] transition-all flex items-center justify-between group ${activeTab === item.id ? 'bg-white text-black shadow-2xl scale-105' : 'bg-white/5 border border-white/5 hover:border-white/10'}`}>
              <div className="flex items-center gap-4"><span>{item.icon}</span><span>{item.label}</span></div>
              {activeTab === item.id && <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: accent }}></div>}
            </button>
          ))}
          <div className="mt-10 p-8 bg-black border border-white/5 rounded-[3rem] space-y-4">
             <div className="flex justify-between items-center"><p className="text-[8px] font-black uppercase opacity-20">Live System Logs</p><div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></div></div>
             <div className="font-mono text-[8px] text-white/40 space-y-1 h-32 overflow-y-auto no-scrollbar">{logs.map((l, i) => <p key={i}>{l}</p>)}</div>
          </div>
        </aside>

        <div className="flex-grow min-h-[750px]">
          {activeTab === 'analytics' && <AnalyticsWorkspace accent={accent} />}
          {activeTab === 'crm' && <CRMWorkspace subscribers={subscribers} accent={accent} />}
          {activeTab === 'marketing' && <MarketingAI brandName={brandName} accent={accent} />}
          {activeTab === 'inventory' && <InventoryWorkspace stock={stock} setStock={setStock} accent={accent} releaseDate={releaseDate} onUpdateReleaseDate={onUpdateReleaseDate} />}
          {activeTab === 'system' && <SystemWorkspace accent={accent} setAccent={setAccent} announcement={announcement} setAnnouncement={setAnnouncement} />}
          {activeTab === 'tools' && <ToolsWorkspace accent={accent} isLocked={isLocked} setIsLocked={setIsLocked} stock={stock} setStock={setStock} subscribers={subscribers} addLog={addLog} />}
        </div>
      </div>
    </div>
  );
};

/* --- Tools Workspace with Real Functionality --- */

const ToolsWorkspace = ({ accent, isLocked, setIsLocked, stock, setStock, subscribers, addLog }: any) => {
  const [selectedTool, setSelectedTool] = useState<string | null>(null);
  
  // States for specific tools
  const [coupons, setCoupons] = useState<Coupon[]>([{ code: 'NUVVO10', discount: 10 }]);
  const [newCoupon, setNewCoupon] = useState({ code: '', discount: 0 });
  const [broadcastMessage, setBroadcastMessage] = useState("");
  const [isColombiaOnly, setIsColombiaOnly] = useState(true);

  const toolsList = [
    { id: 'coupon', n: "Coupon Engine", d: "Gestionar descuentos 001" },
    { id: 'broadcast', n: "Mass Broadcast", d: "Email masivo a todos los nodos" },
    { id: 'security', n: "Security Shield", d: `Nivel de firewall actual: ${isLocked ? 'OFFLINE' : 'ACTIVE'}` },
    { id: 'stock', n: "Stock Injector", d: "Inyección rápida de stock masivo" },
    { id: 'lock', n: "Regional Lock", d: `Actualmente: ${isColombiaOnly ? 'Colombia' : 'Global'}` },
    { id: 'ghost', n: "Ghost UI", d: "Modo mantenimiento visual" }
  ];

  if (selectedTool === 'coupon') {
    return (
      <div className="space-y-8 animate-in slide-in-from-right-10">
        <button onClick={() => setSelectedTool(null)} className="text-[10px] font-black uppercase tracking-widest opacity-40 hover:opacity-100 flex items-center gap-2">← VOLVER AL MENÚ</button>
        <div className="bg-white/5 border border-white/10 rounded-[4rem] p-12 space-y-10">
          <h3 className="text-4xl font-black italic tracking-tighter uppercase">Coupon Engine</h3>
          <div className="grid grid-cols-2 gap-4">
            <input placeholder="CÓDIGO" value={newCoupon.code} onChange={e => setNewCoupon({...newCoupon, code: e.target.value.toUpperCase()})} className="bg-black/40 border border-white/5 rounded-2xl py-6 px-10 font-bold italic outline-none text-white" />
            <input type="number" placeholder="% DESC" value={newCoupon.discount || ''} onChange={e => setNewCoupon({...newCoupon, discount: parseInt(e.target.value)})} className="bg-black/40 border border-white/5 rounded-2xl py-6 px-10 font-bold italic outline-none text-white" />
          </div>
          <button onClick={() => { if(newCoupon.code) setCoupons([...coupons, newCoupon]); setNewCoupon({code: '', discount:0}); addLog(`Cupón ${newCoupon.code} creado.`); }} className="w-full py-6 rounded-full font-black uppercase tracking-widest text-[10px]" style={{ backgroundColor: accent }}>Crear Descuento</button>
          <div className="space-y-4">
            {coupons.map((c, i) => (
              <div key={i} className="flex justify-between items-center p-6 bg-white/5 rounded-3xl">
                <span className="font-black italic text-xl">{c.code}</span>
                <span className="font-mono text-green-500">-{c.discount}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (selectedTool === 'broadcast') {
    return (
      <div className="space-y-8 animate-in slide-in-from-right-10">
        <button onClick={() => setSelectedTool(null)} className="text-[10px] font-black uppercase tracking-widest opacity-40 hover:opacity-100 flex items-center gap-2">← VOLVER AL MENÚ</button>
        <div className="bg-white/5 border border-white/10 rounded-[4rem] p-12 space-y-10">
          <h3 className="text-4xl font-black italic tracking-tighter uppercase">Mass Broadcast</h3>
          <p className="text-xs font-bold opacity-40 uppercase tracking-widest">Enviar a {subscribers.length} nodos activos.</p>
          <textarea value={broadcastMessage} onChange={e => setBroadcastMessage(e.target.value)} placeholder="ESCRIBE TU COMUNICADO..." className="w-full h-40 bg-black/40 border border-white/5 rounded-[2.5rem] p-10 outline-none text-white font-bold italic" />
          <button onClick={() => { addLog(`Broadcast enviado a ${subscribers.length} nodos.`); setBroadcastMessage(""); alert("BROADCAST COMPLETADO"); }} className="w-full py-8 rounded-full font-black uppercase text-[10px] tracking-widest" style={{ backgroundColor: accent }}>Ejecutar Protocolo de Envío</button>
        </div>
      </div>
    );
  }

  if (selectedTool === 'security') {
    return (
      <div className="space-y-8 animate-in slide-in-from-right-10">
        <button onClick={() => setSelectedTool(null)} className="text-[10px] font-black uppercase tracking-widest opacity-40 hover:opacity-100 flex items-center gap-2">← VOLVER AL MENÚ</button>
        <div className="bg-white/5 border border-white/10 rounded-[4rem] p-12 text-center space-y-10">
          <h3 className="text-4xl font-black italic tracking-tighter uppercase">Security Shield</h3>
          <div className="py-20 flex flex-col items-center gap-8">
            <div className={`w-32 h-32 rounded-full border-8 flex items-center justify-center text-4xl animate-pulse ${isLocked ? 'border-red-500' : 'border-green-500'}`}>
              {isLocked ? '🔒' : '🔓'}
            </div>
            <p className="text-[10px] font-black tracking-[0.4em] uppercase opacity-40">ESTADO ACTUAL: {isLocked ? 'SYSTEM_LOCKED' : 'ONLINE'}</p>
            <button onClick={() => { setIsLocked(!isLocked); addLog(`Escudo de seguridad: ${!isLocked ? 'LOCKED' : 'UNLOCKED'}`); }} className={`px-16 py-6 rounded-full font-black uppercase tracking-widest text-[10px] transition-all ${isLocked ? 'bg-green-500 text-black' : 'bg-red-500 text-white shadow-[0_0_50px_rgba(255,59,48,0.3)]'}`}>
              {isLocked ? 'Abrir Sistema' : 'Activar Protocolo de Cierre'}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-6 animate-in fade-in slide-in-from-right-10">
      {toolsList.map(tool => (
        <button key={tool.id} onClick={() => {
          if(tool.id === 'stock') {
            setStock({ S: stock.S + 10, M: stock.M + 10, L: stock.L + 10 });
            addLog("Inyección masiva: +10 en todas las tallas.");
          } else if(tool.id === 'lock') {
            setIsColombiaOnly(!isColombiaOnly);
            addLog(`Regional Lock: ${!isColombiaOnly ? 'Colombia' : 'Global'}`);
          } else if(tool.id === 'ghost') {
            alert("GHOST UI: Solo disponible en v4.6");
          } else {
            setSelectedTool(tool.id);
          }
        }} className="bg-white/5 border border-white/5 rounded-[2.5rem] p-8 text-left hover:border-white/20 transition-all group relative overflow-hidden">
          <div className="absolute top-0 right-0 w-8 h-8 opacity-10 group-hover:opacity-100 transition-opacity p-2" style={{ color: accent }}>↗</div>
          <p className="text-[8px] font-black uppercase tracking-[0.4em] opacity-30 italic mb-2">UTILITY_ACCESS</p>
          <p className="text-lg font-black italic uppercase tracking-tighter mb-1">{tool.n}</p>
          <p className="text-[9px] opacity-40 font-bold">{tool.d}</p>
        </button>
      ))}
      <div className="col-span-full py-16 bg-white/[0.02] rounded-[4rem] border border-dashed border-white/10 flex flex-col items-center justify-center opacity-30">
         <p className="text-[10px] font-black uppercase tracking-[0.8em]">88+ Protocolos Master en espera...</p>
      </div>
    </div>
  );
};

const AnalyticsWorkspace = ({ accent }: any) => {
  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-right-10">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard label="VISITAS ÚNICAS" value="12.8K" sub="+44% Velocity" accent={accent} />
        <StatCard label="TASA DE CLICK" value="21.5%" sub="High Intent" accent={accent} />
        <StatCard label="CONVERSIÓN" value="3.1%" sub="Drop Standard" accent={accent} />
        <StatCard label="SALUD NODO" value="99.9%" sub="Uptime Master" accent={accent} />
      </div>
      <div className="bg-white/5 border border-white/10 rounded-[4rem] p-16 space-y-12">
         <div className="flex justify-between items-end">
            <div className="space-y-1">
               <h4 className="text-3xl font-black uppercase italic tracking-tighter">Tráfico Global</h4>
               <p className="text-[10px] font-bold opacity-30 uppercase tracking-widest">Actividad de Red en Tiempo Real</p>
            </div>
            <div className="flex gap-2">
               {['D', 'W', 'M'].map(p => <button key={p} className={`w-8 h-8 rounded-full border border-white/10 text-[9px] font-black ${p === 'D' ? 'bg-white text-black' : 'opacity-40'}`}>{p}</button>)}
            </div>
         </div>
         <div className="h-64 flex items-end gap-3 px-4">
            {[30, 50, 45, 80, 65, 90, 40, 55, 75, 85, 60, 95, 70, 40, 30].map((h, i) => (
              <div key={i} className="flex-grow bg-white/5 rounded-full relative group transition-all" style={{ height: `${h}%` }}>
                <div className="absolute inset-0 bg-white/10 rounded-full scale-y-0 group-hover:scale-y-100 transition-transform origin-bottom" style={{ backgroundColor: accent }}></div>
              </div>
            ))}
         </div>
      </div>
    </div>
  );
};

/* --- Enhanced Checkout with Professional Receipt --- */

const CheckoutModal = ({ step, setStep, onClose, total, cart, user, onLock, accent }: any) => {
  const [loading, setLoading] = useState(false);
  const [receiptData, setReceiptData] = useState<any>(null);

  const handleFinalize = () => {
    setLoading(true);
    const data = {
      id: `NV-${Math.floor(Math.random() * 999999).toString(16).toUpperCase()}`,
      date: new Date().toLocaleString(),
      items: [...cart],
      total,
      userNode: user?.nodeId || 'N/A',
      userName: user?.name || 'ANONYMOUS'
    };
    setTimeout(() => { 
      setReceiptData(data);
      setLoading(false); 
      setStep(4);
    }, 3000);
  };

  return (
    <div className="fixed inset-0 z-[2000] flex items-center justify-center p-6 bg-black/98 backdrop-blur-3xl animate-in fade-in duration-500">
      <div className="relative w-full max-w-4xl bg-[#0a0a0a] border-2 border-white/10 rounded-[4rem] overflow-hidden shadow-2xl flex flex-col">
        {loading ? (
          <div className="h-[650px] flex flex-col items-center justify-center space-y-8">
            <div className="w-20 h-20 border-4 border-white/10 border-t-white rounded-full animate-spin"></div>
            <p className="font-black text-[10px] tracking-[0.8em] animate-pulse italic" style={{ color: accent }}>PROCESANDO PROTOCOLO DE PAGO...</p>
          </div>
        ) : step === 4 ? (
          <div className="p-16 flex flex-col items-center animate-in zoom-in duration-700 overflow-y-auto max-h-[90vh] no-scrollbar">
            <div className="w-full max-w-2xl bg-white text-black p-12 rounded-sm shadow-2xl space-y-12 relative overflow-hidden">
               {/* Aesthetic Receipt Design */}
               <div className="absolute top-0 right-0 p-8 opacity-10 font-black text-6xl rotate-45 select-none">OFFICIAL</div>
               <div className="flex justify-between items-start border-b-4 border-black pb-8">
                  <div className="space-y-1">
                     <h2 className="text-4xl font-black italic tracking-tighter">NUVVO STUDIO</h2>
                     <p className="text-[10px] font-black opacity-60">ARCHIVO_TRANSACCIÓN_001</p>
                  </div>
                  <div className="text-right space-y-1">
                     <p className="text-[10px] font-black uppercase opacity-60">ID DE ORDEN</p>
                     <p className="text-lg font-black">{receiptData?.id}</p>
                  </div>
               </div>
               
               <div className="grid grid-cols-2 gap-10">
                  <div className="space-y-2">
                     <p className="text-[9px] font-black uppercase opacity-40 tracking-widest">CLIENTE_NODO</p>
                     <div className="font-mono text-sm font-bold uppercase leading-none">
                        {receiptData?.userName} <br/>
                        ID: {receiptData?.userNode}
                     </div>
                  </div>
                  <div className="space-y-2 text-right">
                     <p className="text-[9px] font-black uppercase opacity-40 tracking-widest">FECHA_EMISIÓN</p>
                     <p className="font-mono text-sm font-bold uppercase">{receiptData?.date}</p>
                  </div>
               </div>

               <table className="w-full text-left">
                  <thead className="border-b-2 border-black">
                     <tr className="text-[10px] font-black uppercase opacity-40">
                        <th className="py-4">PIEZA_DETALLE</th>
                        <th className="text-center">TALLA</th>
                        <th className="text-right">VALOR</th>
                     </tr>
                  </thead>
                  <tbody className="font-mono text-sm">
                     {receiptData?.items.map((it: any, i: number) => (
                       <tr key={i} className="border-b border-black/10">
                          <td className="py-6 font-black uppercase">{it.quantity}x {it.name}</td>
                          <td className="text-center font-bold">{it.size}</td>
                          <td className="text-right font-black">${(it.price * it.quantity).toLocaleString()}</td>
                       </tr>
                     ))}
                  </tbody>
               </table>

               <div className="space-y-4 border-t-4 border-black pt-8">
                  <div className="flex justify-between items-center text-sm font-bold opacity-40 uppercase"><span>Subtotal Drop</span><span>${receiptData?.total.toLocaleString()}</span></div>
                  <div className="flex justify-between items-center text-sm font-bold opacity-40 uppercase"><span>Protocolo Envío (COL)</span><span>$0.00</span></div>
                  <div className="flex justify-between items-center text-3xl font-black italic tracking-tighter border-t border-black/10 pt-4">
                     <span>TOTAL_FINAL</span>
                     <span>${receiptData?.total.toLocaleString()} COP</span>
                  </div>
               </div>

               <div className="flex justify-between items-end pt-12">
                  <div className="w-24 h-24 bg-black flex items-center justify-center p-2 rounded-sm opacity-90">
                     <div className="w-full h-full bg-white flex flex-col gap-1 items-center justify-center">
                        <div className="w-full h-1.5 bg-black"></div>
                        <div className="w-full h-0.5 bg-black"></div>
                        <div className="w-full h-2.5 bg-black"></div>
                        <div className="w-full h-1 bg-black"></div>
                     </div>
                  </div>
                  <div className="text-right max-w-xs space-y-2 opacity-30">
                     <p className="text-[7px] font-black leading-relaxed uppercase">nuvvo studio © 2024. Este documento es un comprobante digital de autenticidad para el Drop 001. No reembolsable bajo protocolos de edición limitada.</p>
                     <p className="text-[8px] font-mono font-bold italic tracking-widest">MADE IN COLOMBIA / NUVVO OS</p>
                  </div>
               </div>
            </div>
            <div className="mt-12 flex gap-4">
               <button onClick={() => window.print()} className="px-10 py-4 bg-white/5 border border-white/10 rounded-full font-black uppercase text-[10px] tracking-widest hover:bg-white/10 transition-all">Exportar PDF</button>
               <button onClick={onClose} className="px-10 py-4 bg-white text-black rounded-full font-black uppercase text-[10px] tracking-widest hover:scale-105 transition-all">Finalizar Protocolo</button>
            </div>
          </div>
        ) : (
          <div className="p-20 space-y-12">
            <div className="flex justify-between items-end border-b border-white/5 pb-10">
              <div className="space-y-2">
                <span className="text-[10px] font-black uppercase italic" style={{ color: accent }}>CHECKOUT 0{step} / 03</span>
                <h3 className="text-6xl font-black italic tracking-tighter">{step === 1 ? 'ENVÍO' : step === 2 ? 'PAGO' : 'CORE'}</h3>
              </div>
              <p className="text-4xl font-black italic tracking-tighter tabular-nums">${total.toLocaleString()}</p>
            </div>
            <div className="space-y-8 min-h-[280px]">
              {step === 1 ? (
                <div className="grid grid-cols-2 gap-8">
                  <Input label="NODO_ID" placeholder={user?.nodeId || "N/A"} accent={accent} disabled />
                  <Input label="EMAIL_PROTOCOL" placeholder={user?.email || "N/A"} accent={accent} disabled />
                  <div className="col-span-2"><Input label="DIRECCIÓN DE ENTREGA (COLOMBIA)" placeholder="Ciudad, Calle, Apt..." accent={accent} /></div>
                </div>
              ) : step === 2 ? (
                <div className="space-y-8">
                  <Input label="TARJETA MAESTRA" placeholder="**** **** **** ****" accent={accent} />
                  <div className="grid grid-cols-2 gap-8"><Input label="EXP" placeholder="MM/YY" accent={accent} /><Input label="CVC_CODE" placeholder="***" accent={accent} /></div>
                </div>
              ) : (
                <div className="bg-white/5 p-10 rounded-[3rem] border border-white/5 space-y-4 max-h-[300px] overflow-y-auto no-scrollbar">
                  {cart.map((item: CartItem, i: number) => (
                    <div key={i} className="flex justify-between text-xs font-bold opacity-60"><span>{item.quantity}x {item.name} ({item.size})</span><span>${(item.price * item.quantity).toLocaleString()}</span></div>
                  ))}
                  <div className="pt-6 border-t border-white/10 flex justify-between text-white text-xl font-black italic"><span>Total a Confirmar</span><span>${total.toLocaleString()}</span></div>
                </div>
              )}
            </div>
            <div className="flex gap-6 pt-10">
              {step > 1 && <button onClick={() => setStep(step - 1)} className="px-12 border border-white/10 rounded-full font-black text-[10px] italic hover:bg-white/5 transition-all">VOLVER</button>}
              <button onClick={step === 3 ? handleFinalize : () => setStep(step + 1)} style={{ backgroundColor: accent, color: 'white' }} className="flex-grow py-8 rounded-full font-black uppercase tracking-[1em] text-[10px] italic shadow-2xl hover:opacity-90 transition-all">
                {step === 3 ? 'FINALIZAR TRANSACCIÓN' : 'CONTINUAR'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

/* --- Global Sub-Components --- */

const StatCard = ({ label, value, sub, accent }: any) => (
  <div className="bg-white/5 border border-white/10 rounded-[2.5rem] p-10 space-y-4 hover:border-white/20 transition-all group backdrop-blur-3xl relative overflow-hidden">
    <div className="absolute top-0 right-0 w-24 h-24 blur-[60px] opacity-10" style={{ backgroundColor: accent }}></div>
    <p className="text-[9px] font-black uppercase tracking-[0.4em] opacity-30 italic" style={{ color: accent }}>{label}</p>
    <p className="text-5xl font-black italic tracking-tighter tabular-nums mb-2">{value}</p>
    <p className="text-[10px] font-bold opacity-20 uppercase tracking-widest">{sub}</p>
  </div>
);

const Input = ({ label, placeholder, value, onChange, disabled }: any) => (
  <div className="space-y-3">
    <label className="text-[10px] font-black uppercase tracking-widest text-white/20 italic ml-4">{label}</label>
    <input disabled={disabled} value={value} onChange={onChange} placeholder={placeholder} className={`w-full bg-white/5 border border-white/5 rounded-3xl py-6 px-10 text-sm font-bold text-white outline-none focus:border-white/30 transition-all italic placeholder:opacity-10 ${disabled ? 'opacity-40 cursor-not-allowed' : ''}`} />
  </div>
);

const CountdownDisplay = ({ targetDate, accent, mini = false }: any) => {
  const { days, hours, minutes, seconds, expired } = useCountdown(targetDate);
  if (expired) return <div className="text-green-500 font-black italic animate-pulse tracking-[0.6em] text-sm uppercase">Drop Protocol: Active // 001 En Vivo</div>;
  const Unit = ({ v, l }: any) => (
    <div className="flex flex-col items-center">
      <span className={`${mini ? 'text-2xl' : 'text-4xl md:text-8xl'} font-black italic tabular-nums tracking-tighter leading-none`}>{v.toString().padStart(2, '0')}</span>
      <span className={`${mini ? 'text-[6px]' : 'text-[9px]'} font-black uppercase tracking-[0.4em] opacity-30 mt-2`}>{l}</span>
    </div>
  );
  return (
    <div className={`flex items-center justify-center ${mini ? 'gap-4' : 'gap-10 md:gap-24'}`}>
      <Unit v={days} l="Días" />
      <span className="opacity-20 font-black italic text-4xl">:</span>
      <Unit v={hours} l="Horas" />
      <span className="opacity-20 font-black italic text-4xl">:</span>
      <Unit v={minutes} l="Minutos" />
      <Unit v={seconds} l="Segs" className="hidden md:flex" />
    </div>
  );
};

const useCountdown = (targetDate: string) => {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0, expired: false });
  useEffect(() => {
    const timer = setInterval(() => {
      const dist = new Date(targetDate).getTime() - new Date().getTime();
      if (dist < 0) { setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0, expired: true }); clearInterval(timer); }
      else { setTimeLeft({ days: Math.floor(dist/(1000*60*60*24)), hours: Math.floor((dist%(1000*60*60*24))/(1000*60*60)), minutes: Math.floor((dist%(1000*60*60))/(1000*60)), seconds: Math.floor((dist%(1000*60))/1000), expired: false }); }
    }, 1000);
    return () => clearInterval(timer);
  }, [targetDate]);
  return timeLeft;
};

const Navbar = ({ brandName, setBrandName, editMode, cartCount, onOpenCart, isAdmin, accent, currentUser }: any) => (
  <nav className="fixed top-12 w-full z-50 border-b border-white/10 glass">
    <div className="max-w-7xl mx-auto px-6 h-20 flex justify-between items-center">
      <div className="flex items-center gap-4">
        {editMode ? (
          <input value={brandName} onChange={(e) => setBrandName(e.target.value)} className="text-3xl font-black lowercase bg-white/10 px-2 rounded w-40 outline-none text-white border border-white/20" />
        ) : (
          <div className="text-4xl nuvvo-logo-white lowercase cursor-pointer" onClick={() => window.scrollTo(0, 0)}>{brandName}</div>
        )}
        {isAdmin && <span className="text-[10px] font-black uppercase tracking-[0.3em] italic" style={{ color: accent }}>Admin</span>}
      </div>
      <div className="hidden md:flex space-x-12 text-[10px] font-black uppercase tracking-[0.4em] text-white/50 italic">
        {NAV_LINKS.map(link => <a key={link} href={`#${link.toLowerCase()}`} className="hover:text-white transition-all hover:tracking-[0.5em]">{link}</a>)}
      </div>
      <div className="flex items-center space-x-6">
        {currentUser && (
          <div className="hidden lg:flex items-center gap-3">
             <div className="w-2 h-2 rounded-full animate-pulse" style={{ backgroundColor: accent }}></div>
             <span className="text-[9px] font-black uppercase tracking-widest opacity-40 italic">{currentUser.nodeId}</span>
          </div>
        )}
        <button onClick={onOpenCart} className="p-2 relative group flex items-center gap-3 bg-white/5 px-6 py-2 rounded-full border border-white/5 hover:border-white/20 transition-all">
          <CartIcon />
          <span className="text-[9px] font-black uppercase tracking-widest hidden md:block">Bolsa</span>
          {cartCount > 0 && <span style={{ backgroundColor: accent }} className="text-white text-[9px] w-5 h-5 rounded-full flex items-center justify-center font-black animate-in zoom-in">{cartCount}</span>}
        </button>
      </div>
    </div>
  </nav>
);

const HeroSection = ({ heroText, setHeroText, editMode, brandName, accent, releaseDate }: any) => (
  <section className="relative h-screen flex items-center justify-center overflow-hidden">
    <div className="absolute inset-0 bg-gradient-to-b from-black via-transparent to-black z-10"></div>
    <video autoPlay loop muted playsInline className="absolute inset-0 w-full h-full object-cover opacity-30 grayscale contrast-125">
      <source src="https://assets.mixkit.co/videos/preview/mixkit-urban-traffic-light-at-night-42204-large.mp4" type="video/mp4" />
    </video>
    <div className="relative z-20 text-center px-6 max-w-5xl">
      <div className="flex items-center justify-center space-x-4 mb-8">
        <div className="h-[1px] w-12 bg-white/20"></div>
        <span className="text-[10px] uppercase tracking-[1em] font-black text-white/40 italic">Drop 001 // Sistema Sincronizado</span>
        <div className="h-[1px] w-12 bg-white/20"></div>
      </div>
      {editMode ? (
        <textarea value={heroText} onChange={(e) => setHeroText(e.target.value)} className="text-6xl md:text-9xl font-black mb-12 bg-black/40 p-8 w-full text-center outline-none border-b-8 rounded-t-3xl text-white italic" style={{ borderBottomColor: accent }} />
      ) : (
        <div className="space-y-12">
          <h1 className="text-7xl md:text-[14rem] font-black leading-none tracking-tighter uppercase italic drop-shadow-[0_20px_50px_rgba(0,0,0,0.8)] animate-in fade-in slide-in-from-bottom-10 duration-1000">
            {heroText}
          </h1>
          <div className="py-12 animate-in fade-in duration-1000 delay-300">
             <CountdownDisplay targetDate={releaseDate} accent={accent} />
          </div>
        </div>
      )}
      <div className="mt-12">
        <a href="#aura" className="inline-flex items-center space-x-6 bg-white text-black px-16 py-8 rounded-full hover:scale-105 transition-all duration-500 group shadow-2xl">
          <span className="uppercase tracking-[0.4em] text-sm font-black italic">Explorar Drop</span>
          <ArrowRightIcon />
        </a>
      </div>
    </div>
  </section>
);

const ProductShowcase = ({ brandName, onAddToCart, onOpenSizeGuide, accent, stock, isLocked }: any) => {
  const [selectedSize, setSelectedSize] = useState<string | null>(null);
  const images = [
    { type: 'FRONTAL', url: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?q=80&w=1000&auto=format&fit=crop" },
    { type: 'DETALLE', url: "https://images.unsplash.com/photo-1554568218-0f1715e72254?q=80&w=1000&auto=format&fit=crop" }
  ];

  const handleAdd = () => {
    if (isLocked) { alert("DROP LOCKED: Vuelve cuando el contador llegue a cero."); return; }
    if (!selectedSize) { alert("SELECCIONA TALLA"); return; }
    if (stock[selectedSize as keyof StockLevels] <= 0) { alert("TALLA AGOTADA"); return; }
    onAddToCart({ id: 'aura-001', name: `${brandName} Aura 001`, size: selectedSize, price: 185000, image: images[0].url });
  };

  return (
    <section id="aura" className="py-40 max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-24 items-start relative border-t border-white/5">
      <div className="sticky top-40 space-y-12">
        <div className="space-y-6">
          <div style={{ backgroundColor: isLocked ? '#333' : accent }} className="inline-block text-white px-8 py-3 text-[10px] font-black uppercase tracking-[0.4em] italic rounded-full shadow-2xl">
             {isLocked ? 'ESTADO: BLOQUEADO' : 'PROTOCOLO DROP 001 ACTIVO'}
          </div>
          <h2 className="text-8xl font-black uppercase italic tracking-tighter leading-[0.85] text-white">
            AURA <span style={{ color: accent }}>CORE</span>
          </h2>
          <p className="text-xl font-bold text-white/30 leading-relaxed max-w-md italic">
            Heavyweight 350GSM Cotton. <br/> Arquitectura Brutalista. <br/> Edición Limitada a 30 piezas.
          </p>
        </div>

        <div className="space-y-10">
          <div className="flex items-baseline space-x-6">
            <span className="text-7xl font-black italic tracking-tighter">$185.000</span>
            <span className="text-[10px] font-black uppercase tracking-widest text-white/20 italic">COP / NAL</span>
          </div>

          <div className="space-y-6">
            <div className="flex justify-between items-end">
              <p className="text-[10px] font-black uppercase tracking-[0.5em] text-white/20 italic">Talla de Nodo:</p>
              <button onClick={onOpenSizeGuide} className="text-[9px] font-black uppercase tracking-widest hover:text-white transition-colors underline underline-offset-8 italic" style={{ color: accent }}>Guía de Fit</button>
            </div>
            <div className="grid grid-cols-3 gap-6">
              {(['S', 'M', 'L'] as const).map(size => {
                const available = stock[size] > 0;
                return (
                  <button key={size} disabled={!available || isLocked} onClick={() => setSelectedSize(size)} className={`py-6 rounded-[2rem] border-2 transition-all font-black text-3xl italic flex flex-col items-center justify-center ${selectedSize === size ? 'border-white text-white shadow-2xl scale-105' : 'border-white/5 text-white/10 hover:border-white/40'} ${(!available || isLocked) ? 'opacity-10 cursor-not-allowed border-dashed' : ''}`} style={{ backgroundColor: selectedSize === size ? accent : 'transparent' }}>
                    {size}
                    <span className="text-[9px] mt-2 tracking-widest opacity-40">{available ? `${stock[size]} DISP` : 'SOLD'}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <button onClick={handleAdd} disabled={isLocked} className={`group relative w-full ${isLocked ? 'bg-white/5 text-white/10' : 'bg-white text-black'} py-10 rounded-full font-black uppercase tracking-[0.6em] text-sm hover:scale-[1.01] transition-all shadow-2xl active:scale-95 italic overflow-hidden`}>
            <span className="relative z-10">{isLocked ? 'DROP BLOQUEADO' : 'Añadir a Bolsa'}</span>
          </button>
        </div>
      </div>

      <div className="space-y-12">
        {images.map((img, i) => (
          <div key={i} className="group relative aspect-[3/4] bg-[#0a0a0a] rounded-[4rem] overflow-hidden border border-white/5 shadow-2xl transition-all">
            <div style={{ color: accent }} className="absolute top-12 left-12 z-20 text-[10px] font-black uppercase tracking-[0.6em] italic bg-black/80 px-6 py-2 rounded-full backdrop-blur-md border border-white/10">{img.type}</div>
            <img src={img.url} className="w-full h-full object-cover grayscale brightness-75 transition-all duration-1000 group-hover:grayscale-0 group-hover:brightness-100 group-hover:scale-105" />
          </div>
        ))}
      </div>
    </section>
  );
};

const ArchiveSection = ({ accent }: any) => {
  const archives = [
    { title: "Drop 000: Industrial", date: "Jan 2023", soldOut: true, img: "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?q=80&w=1000&auto=format&fit=crop" },
    { title: "Drop Prototype: V1", date: "Aug 2022", soldOut: true, img: "https://images.unsplash.com/photo-1543076447-215ad9ba6923?q=80&w=1000&auto=format&fit=crop" }
  ];
  return (
    <section id="archivo" className="py-40 px-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-baseline mb-24 gap-8">
        <h2 className="text-7xl font-black uppercase italic tracking-tighter">Archivo</h2>
        <div className="h-[2px] flex-grow bg-white/5 hidden md:block mx-12"></div>
        <p className="text-[10px] font-black uppercase tracking-[0.6em] opacity-20 italic">Historización</p>
      </div>
      <div className="grid md:grid-cols-2 gap-12">
        {archives.map((item, i) => (
          <div key={i} className="group relative aspect-[16/9] bg-white/5 rounded-[3rem] overflow-hidden border border-white/5 transition-all hover:scale-[1.02] cursor-not-allowed">
            <img src={item.img} className="w-full h-full object-cover opacity-40 grayscale transition-all duration-1000" />
            <div className="absolute inset-0 flex flex-col justify-end p-12 bg-gradient-to-t from-black to-transparent">
              <span className="text-[9px] font-black uppercase tracking-widest mb-2 opacity-40">{item.date}</span>
              <h4 className="text-4xl font-black uppercase italic tracking-tighter">{item.title}</h4>
              <div className="mt-6 flex items-center gap-4"><div className="px-6 py-2 border-2 rounded-full text-[9px] font-black uppercase tracking-widest" style={{ borderColor: accent, color: accent }}>SOLD OUT</div></div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

const InfoSection = ({ brandName, accent }: any) => (
  <section id="nosotros" className="py-40 bg-white text-black px-6 overflow-hidden">
    <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-32 items-center">
      <div className="space-y-12">
        <h2 className="text-7xl md:text-9xl font-black uppercase italic tracking-tighter leading-[0.8]">{brandName} Studio</h2>
        <p className="text-2xl font-bold leading-relaxed text-black/90 italic">Nuestra propuesta combina estética brutalista, cortes arquitectónicos y materiales de alto gramaje.</p>
      </div>
      <div className="p-16 bg-black text-white rounded-[4rem] space-y-12 shadow-2xl relative">
        <h3 className="text-[10px] font-black uppercase tracking-[0.6em] italic" style={{ color: accent }}>Core Values</h3>
        <div className="space-y-10">
          {[{ t: "IDENTITY", s: "NODO MAESTRO" }, { t: "BRUTALISM", s: "PURE DESIGN" }, { t: "LOCAL", s: "COLOMBIA BASE" }].map((v, i) => (
            <div key={i} className="border-l-8 pl-8 py-2 transition-all hover:translate-x-2" style={{ borderLeftColor: accent }}>
              <p className="text-5xl font-black italic tracking-tighter leading-none mb-2">{v.t}</p>
              <p className="text-[10px] font-bold uppercase tracking-widest opacity-30">{v.s}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  </section>
);

const CartDrawer = ({ isOpen, onClose, cart, onUpdateQuantity, onRemove, total, onCheckout, accent }: any) => (
  <>
    <div className={`fixed inset-0 bg-black/90 backdrop-blur-2xl z-[500] transition-opacity duration-700 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} onClick={onClose}/>
    <div className={`fixed top-0 right-0 h-full w-full max-w-xl bg-[#0a0a0a] z-[600] border-l border-white/10 transition-transform duration-700 ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
      <div className="flex flex-col h-full">
        <div className="p-16 border-b border-white/5 flex justify-between items-center">
          <h3 className="text-5xl font-black italic uppercase tracking-tighter">Bolsa</h3>
          <button onClick={onClose} className="w-16 h-16 rounded-full border border-white/10 flex items-center justify-center hover:bg-white hover:text-black transition-all">✕</button>
        </div>
        <div className="flex-grow overflow-y-auto p-16 space-y-12 no-scrollbar">
          {cart.length === 0 ? (
            <div className="flex flex-col items-center justify-center pt-20 space-y-8 opacity-20"><CartIcon size={120} /><p className="text-center font-black uppercase tracking-[0.4em] text-sm italic">Sin items detectados</p></div>
          ) : (
            cart.map((item: CartItem, i: number) => (
              <div key={i} className="flex gap-10 group">
                <div className="w-32 h-44 bg-white/5 rounded-3xl overflow-hidden grayscale group-hover:grayscale-0 transition-all"><img src={item.image} className="w-full h-full object-cover" /></div>
                <div className="flex-grow flex flex-col justify-between py-2">
                  <div className="flex justify-between items-start">
                    <div><h4 className="text-2xl font-black uppercase italic tracking-tighter">{item.name}</h4><p className="text-[10px] opacity-40 font-black tracking-widest mt-2 uppercase">Nodo: {item.size}</p></div>
                    <button onClick={() => onRemove(item.id, item.size)} className="text-[9px] font-black opacity-20 hover:opacity-100 hover:text-red-500 transition-all uppercase">Remover</button>
                  </div>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-6 bg-white/5 px-6 py-2 rounded-full border border-white/5">
                      <button onClick={() => onUpdateQuantity(item.id, item.size, -1)} className="hover:text-red-500">-</button>
                      <span className="text-sm font-black italic">{item.quantity}</span>
                      <button onClick={() => onUpdateQuantity(item.id, item.size, 1)} className="hover:text-green-500">+</button>
                    </div>
                    <span className="font-black italic text-3xl tabular-nums">${(item.price * item.quantity).toLocaleString()}</span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
        <div className="p-16 bg-black border-t border-white/10 space-y-8">
          <div className="flex justify-between items-baseline"><span className="text-[10px] font-black uppercase tracking-[0.6em] opacity-40 italic">Subtotal</span><span className="text-6xl font-black italic tracking-tighter tabular-nums">${total.toLocaleString()}</span></div>
          <button onClick={onCheckout} disabled={cart.length === 0} style={{ backgroundColor: accent }} className="w-full text-white py-10 rounded-full font-black uppercase tracking-[0.8em] text-sm hover:opacity-90 transition-all disabled:opacity-20 italic">Sincronizar Checkout</button>
        </div>
      </div>
    </div>
  </>
);

/* Modals */

const AdminLoginModal = ({ accent, onAuth, onClose }: any) => {
  const [email, setEmail] = useState("");
  const [error, setError] = useState(false);
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onAuth(email)) onClose(); else { setError(true); setTimeout(() => setError(false), 2000); }
  };
  return (
    <div className="fixed inset-0 z-[3000] flex items-center justify-center p-6 bg-black/98 backdrop-blur-3xl animate-in fade-in duration-500">
      <div className={`w-full max-w-xl bg-[#0a0a0a] border border-white/10 rounded-[4rem] p-16 space-y-12 relative shadow-2xl transition-all ${error ? 'border-red-500 scale-95' : ''}`}>
        <button onClick={onClose} className="absolute top-12 right-12 opacity-30 hover:opacity-100 text-3xl transition-all">✕</button>
        <div className="space-y-4"><span className="text-[10px] font-black tracking-[0.8em] italic uppercase" style={{ color: accent }}>Kernel Access</span><h3 className="text-6xl font-black italic uppercase tracking-tighter">Maestro</h3></div>
        <form onSubmit={handleSubmit} className="space-y-8"><Input label="EMAIL" placeholder="admin@nuvvo.io" value={email} onChange={(e: any) => setEmail(e.target.value)} /><button type="submit" style={{ backgroundColor: accent }} className="w-full py-10 rounded-full font-black uppercase text-sm shadow-2xl text-white">Login</button></form>
      </div>
    </div>
  );
};

const SizeGuideModal = ({ onClose, accent }: any) => (
  <div className="fixed inset-0 z-[2000] flex items-center justify-center p-6 bg-black/98 backdrop-blur-3xl animate-in zoom-in-95 duration-500">
    <div className="w-full max-w-2xl bg-[#0a0a0a] border border-white/10 rounded-[4rem] p-16 space-y-12 relative shadow-2xl">
      <button onClick={onClose} className="absolute top-12 right-12 opacity-30 hover:opacity-100 text-3xl transition-all">✕</button>
      <h3 className="text-6xl font-black italic uppercase tracking-tighter">Size Protocol</h3>
      <table className="w-full text-left border-t border-white/5 mt-10">
        <thead className="opacity-20"><tr className="border-b border-white/5 text-[10px] font-black uppercase tracking-widest"><th className="py-6">NODO</th><th>ANCHO</th><th>LARGO</th></tr></thead>
        <tbody className="text-2xl font-black italic">
          <tr className="border-b border-white/5 hover:text-white transition-colors"><td className="py-6">SMALL (S)</td><td>58cm</td><td>72cm</td></tr>
          <tr className="border-b border-white/5 hover:text-white transition-colors"><td className="py-6">MEDIUM (M)</td><td>62cm</td><td>75cm</td></tr>
          <tr className="hover:text-white transition-colors"><td className="py-6">LARGE (L)</td><td>66cm</td><td>78cm</td></tr>
        </tbody>
      </table>
    </div>
  </div>
);

const SupportModal = ({ onClose, accent }: any) => (
  <div className="fixed inset-0 z-[2000] flex items-center justify-center p-6 bg-black/98 backdrop-blur-3xl animate-in slide-in-from-bottom-20 duration-500">
    <div className="w-full max-w-xl bg-[#0a0a0a] border border-white/10 rounded-[4rem] p-16 space-y-12 relative">
      <button onClick={onClose} className="absolute top-12 right-12 opacity-30 hover:opacity-100 text-3xl">✕</button>
      <div className="space-y-4"><span className="text-[10px] font-black tracking-[0.8em] italic" style={{ color: accent }}>CONCIERGE</span><h3 className="text-6xl font-black italic uppercase tracking-tighter">Soporte</h3></div>
      <div className="space-y-6">
        <button className="w-full py-8 rounded-full bg-[#25D366] text-black font-black uppercase text-xs hover:scale-105 transition-all shadow-2xl italic">WhatsApp Concierge</button>
        <button className="w-full py-8 rounded-full border border-white/10 text-white font-black uppercase text-xs hover:bg-white/5 transition-all italic">Email Direct</button>
      </div>
    </div>
  </div>
);

const Footer = ({ brandName, onLock, onAdminClick, onOpenSizeGuide, onOpenSupport, accent, onSubscribe }: any) => {
  const [email, setEmail] = useState("");
  return (
    <footer className="bg-black py-40 px-6 border-t border-white/5">
      <div className="max-w-7xl mx-auto grid md:grid-cols-4 gap-24">
        <div className="col-span-2 space-y-12">
          <div className="text-9xl nuvvo-logo-white lowercase leading-none">{brandName}</div>
          <p className="text-white/20 max-w-sm text-2xl font-bold italic">Diseñado en Colombia para el mundo. Streetwear de autor.</p>
          <button onClick={onAdminClick} className="text-[10px] font-black uppercase tracking-[1em] opacity-10 hover:opacity-100 transition-opacity border border-white/10 px-10 py-3 rounded-full italic">Acceso Maestro OS 4.5</button>
        </div>
        <div className="space-y-10">
          <h4 className="text-[10px] font-black tracking-[0.8em] italic uppercase" style={{ color: accent }}>Nodos</h4>
          <ul className="space-y-6 text-sm font-bold text-white/30 uppercase tracking-[0.4em] italic">
            <li onClick={onOpenSizeGuide} className="hover:text-white cursor-pointer transition-all">Size Protocol</li>
            <li onClick={onOpenSupport} className="hover:text-white cursor-pointer transition-all">Soporte Concierge</li>
          </ul>
        </div>
        <div className="space-y-10">
          <h4 className="text-[10px] font-black tracking-[0.8em] italic uppercase" style={{ color: accent }}>Broadcast</h4>
          <div className="flex border-b border-white/10 py-6 italic">
            <input type="email" placeholder="PROTOCOLO" value={email} onChange={e => setEmail(e.target.value)} className="bg-transparent flex-grow text-sm font-black outline-none uppercase placeholder:opacity-20" />
            <button onClick={() => { if (email.toLowerCase().trim() === ADMIN_EMAIL) onLock(); else { onSubscribe(email); setEmail(""); alert("Node Registered."); } }} className="text-[10px] font-black uppercase hover:opacity-60">OK</button>
          </div>
        </div>
      </div>
    </footer>
  );
};

const CRMWorkspace = ({ subscribers, accent }: any) => (
  <div className="bg-white/5 border border-white/10 rounded-[4rem] p-16 space-y-10 animate-in fade-in slide-in-from-right-10">
    <div className="flex justify-between items-center">
      <h3 className="text-4xl font-black italic uppercase tracking-tighter">Nodos Registrados</h3>
      <button className="px-8 py-3 border border-white/10 rounded-full text-[9px] font-black uppercase tracking-widest hover:bg-white hover:text-black transition-all">Exportar Master List</button>
    </div>
    <div className="overflow-x-auto">
      <table className="w-full text-left">
        <thead className="border-b border-white/10 text-[9px] font-black uppercase tracking-widest opacity-30">
          <tr>
            <th className="py-6 px-4">CLIENTE ID</th>
            <th>EMAIL / PROTOCOLO</th>
            <th>REGISTRO</th>
            <th>TIER</th>
            <th>ACCIONES</th>
          </tr>
        </thead>
        <tbody className="text-[10px] font-bold">
          {subscribers.map((s: Subscriber, i: number) => (
            <tr key={i} className="border-b border-white/5 hover:bg-white/[0.02] transition-colors group">
              <td className="py-6 px-4 font-mono opacity-40">{s.id}</td>
              <td className="italic">{s.email}</td>
              <td className="opacity-40">{s.joinDate.split('T')[0]}</td>
              <td>
                <span className={`px-3 py-1 rounded-full border border-white/10 ${s.tier === 'VIP' ? 'text-yellow-500 border-yellow-500/30' : ''}`}>{s.tier}</span>
              </td>
              <td className="opacity-0 group-hover:opacity-100 transition-opacity">
                <button className="text-[8px] font-black uppercase tracking-widest hover:text-[#ff3b30]">Remover</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </div>
);

const MarketingAI = ({ brandName, accent }: any) => {
  const [prompt, setPrompt] = useState("");
  const [output, setOutput] = useState("");
  const [loading, setLoading] = useState(false);
  const generate = async (type: string) => {
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const systemPrompt = `Eres el director de marketing de ${brandName}, una marca de streetwear brutalista. Escribe 3 ${type} para: ${prompt}. Estilo: Crudo, directo, minimalista. Usa emojis técnicos.`;
      const response = await ai.models.generateContent({ model: 'gemini-3-flash-preview', contents: systemPrompt });
      setOutput(response.text || "");
    } catch (e) { setOutput("ERROR: Conexión denegada."); }
    setLoading(false);
  };
  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-right-10">
      <div className="bg-white/5 border border-white/10 rounded-[4rem] p-16 space-y-10">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-blue-500 flex items-center justify-center text-xl">✴️</div>
          <h3 className="text-4xl font-black italic uppercase tracking-tighter">AI Creative Engine</h3>
        </div>
        <textarea placeholder="Concepto de Campaña..." value={prompt} onChange={(e) => setPrompt(e.target.value)} className="w-full h-40 bg-black/40 border border-white/5 rounded-[2.5rem] p-10 outline-none focus:border-white/20 transition-all font-bold italic text-white" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {['Captions IG', 'Newsletter', 'Web Copy', 'Ads FB'].map(t => (
            <button key={t} onClick={() => generate(t)} className="py-5 rounded-[2rem] border border-white/10 text-[9px] font-black uppercase tracking-widest hover:bg-white hover:text-black transition-all">{t}</button>
          ))}
        </div>
      </div>
      {output && <div className="bg-black border border-white/10 rounded-[4rem] p-16 font-mono text-xs text-white/40 whitespace-pre-wrap leading-relaxed animate-in slide-in-from-bottom-5">{loading ? 'Sincronizando...' : output}</div>}
    </div>
  );
};

const InventoryWorkspace = ({ stock, setStock, accent, releaseDate, onUpdateReleaseDate }: any) => (
  <div className="space-y-10 animate-in fade-in slide-in-from-right-10">
    <div className="grid grid-cols-3 gap-8">
      {(['S', 'M', 'L'] as const).map(sz => (
        <div key={sz} className="bg-white/5 border border-white/5 rounded-[3rem] p-12 space-y-8">
           <div className="flex justify-between items-center"><span className="text-5xl font-black italic">Talla {sz}</span><span className={`text-[8px] font-black px-3 py-1.5 rounded border ${stock[sz] < 5 ? 'text-red-500 border-red-500' : 'text-green-500 border-green-500'}`}>{stock[sz] < 5 ? 'LOW' : 'STABLE'}</span></div>
           <div className="flex gap-4">
              <button onClick={() => setStock({ ...stock, [sz]: Math.max(0, stock[sz]-1) })} className="flex-grow py-6 bg-white/5 rounded-3xl font-black text-xl">-</button>
              <div className="w-24 flex items-center justify-center font-mono text-3xl font-black italic">{stock[sz]}</div>
              <button onClick={() => setStock({ ...stock, [sz]: stock[sz]+1 })} className="flex-grow py-6 bg-white/5 rounded-3xl font-black text-xl">+</button>
           </div>
        </div>
      ))}
    </div>
    <div className="bg-white/5 border border-white/10 rounded-[4rem] p-16 space-y-10">
       <h3 className="text-[10px] font-black uppercase tracking-[0.5em] opacity-30 italic">Programación de Lanzamiento (Core Clock)</h3>
       <input type="datetime-local" value={releaseDate.substring(0, 16)} onChange={(e) => onUpdateReleaseDate(new Date(e.target.value).toISOString())} className="w-full bg-black/40 border border-white/10 rounded-[2.5rem] py-8 px-12 font-black italic outline-none focus:border-white/40 text-white text-lg" />
    </div>
  </div>
);

const SystemWorkspace = ({ accent, setAccent, announcement, setAnnouncement }: any) => (
  <div className="bg-white/5 border border-white/10 rounded-[4rem] p-16 space-y-16 animate-in fade-in slide-in-from-right-10">
    <div className="space-y-8">
      <h3 className="text-[10px] font-black uppercase tracking-[0.5em] opacity-30 italic">Personalización del OS</h3>
      <div className="flex flex-wrap gap-6">
        {["#ff3b30", "#007aff", "#34c759", "#ffcc00", "#af52de", "#ffffff"].map(c => (
          <button key={c} onClick={() => setAccent(c)} style={{ backgroundColor: c }} className={`w-16 h-16 rounded-full border-4 transition-all ${accent === c ? 'border-white scale-125 shadow-2xl' : 'border-transparent'}`} />
        ))}
      </div>
    </div>
    <div className="space-y-8">
      <h3 className="text-[10px] font-black uppercase tracking-[0.5em] opacity-30 italic">Mensaje de Cabecera (Broadcast)</h3>
      <textarea value={announcement} onChange={(e) => setAnnouncement(e.target.value)} className="w-full h-40 bg-black/40 border border-white/10 rounded-[2.5rem] p-12 font-black italic outline-none text-white text-lg" />
    </div>
  </div>
);

const LockdownScreen = ({ email, accent }: any) => (
  <div className="fixed inset-0 bg-black z-[5000] flex flex-col items-center justify-center p-12 text-center animate-pulse">
    <div className="space-y-12 max-w-4xl">
      <div className="text-[12rem] nuvvo-logo-red lowercase leading-none" style={{ color: accent }}>nuvvo</div>
      <h1 className="text-9xl font-black uppercase italic tracking-tighter" style={{ color: accent }}>SYSTEM LOCKDOWN</h1>
      <p className="text-2xl font-bold text-white/20 uppercase tracking-[0.5em] italic">Seguridad de Nodo Nivel 5 Activada</p>
      <div className="p-12 border border-white/5 rounded-[3rem] bg-white/[0.01] text-white/40 text-sm font-black uppercase italic tracking-[0.4em]">Requiere Autorización: {email}</div>
    </div>
  </div>
);

const SearchIcon = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>;
const CartIcon = ({ size = 20 }: any) => <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg>;
const ArrowRightIcon = () => <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>;

const root = createRoot(document.getElementById('root')!);
root.render(<App />);
